#!/usr/bin/env python3
"""
verify_3d_greedy.py
────────────────────────────────────────────────────────────────────────────────
Proves that the 3-D greedy volume-boxing pipeline (v2.0) produces the exact
same visible surface as the v1.x face-sweep pipeline while using fewer elements.

OLD pipeline (v1.x):
  • For each of 6 face directions, sweep every layer, find 2-D rectangles of
    exposed faces, emit 1 quad per rectangle.
  • Phase 4 AABB-packs quads sharing a (from, to) into one element.

NEW pipeline (v2.0):
  • Sweep all solid voxels once, build maximal 3-D boxes (X→Y→Z greedy).
  • For each box, emit 1 quad per exposed face direction (with from/to = full
    box extents).
  • Phase 4 AABB-packing groups all faces of the same box into one element.

Correctness definition:
  Every exposed voxel face (voxel coord, face direction) must be covered by
  exactly one face entry in one element, with an AABB that contains the voxel.

Test models:
  A) Hollow sphere   — organic curved surface, no interior
  B) Solid sphere    — solidFill=true; interior boxes absorbed, zero cost
  C) Stone statue    — cuboid body with arms/legs, solidFill=true
  D) Rough slab      — bumpy surface (clothing/hair proxy)
  E) Single voxel    — pathological best case for 3-D (6 faces → 1 element)
  F) Solid 4×4×4 cube — all interior, only outer shell matters
────────────────────────────────────────────────────────────────────────────────
"""

import itertools, math, random
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

# ── Constants ─────────────────────────────────────────────────────────────────

FACE_NAMES  = ["down", "up", "north", "south", "west", "east"]

# Neighbour delta for each face direction (index matches Face enum)
FACE_DELTA = {
    0: ( 0, -1,  0),  # Down
    1: ( 0,  1,  0),  # Up
    2: ( 0,  0, -1),  # North
    3: ( 0,  0,  1),  # South
    4: (-1,  0,  0),  # West
    5: ( 1,  0,  0),  # East
}

# (sweepAxis, uAxis, vAxis) for each face direction
FACE_AXES = {
    0: (1, 0, 2),  # Down/Up  → sweep Y, u=X, v=Z
    1: (1, 0, 2),
    2: (2, 0, 1),  # North/South → sweep Z, u=X, v=Y
    3: (2, 0, 1),
    4: (0, 2, 1),  # West/East → sweep X, u=Z, v=Y
    5: (0, 2, 1),
}

# ── Data types ────────────────────────────────────────────────────────────────

@dataclass
class Quad:
    from_: Tuple[float,float,float]  # MC-space (full box extents in v2.0)
    to:    Tuple[float,float,float]
    face:  int
    sweep_layer: int
    u_start: int; v_start: int
    u_count: int; v_count: int

@dataclass
class McFace:
    face_name: str

@dataclass
class McElement:
    from_: Tuple[float,float,float]
    to:    Tuple[float,float,float]
    faces: Dict[str, McFace] = field(default_factory=dict)

# ── Voxel grid ────────────────────────────────────────────────────────────────

class VoxelGrid:
    def __init__(self, res: int):
        self.res = res
        self.solid: Set[Tuple[int,int,int]] = set()

    def set_solid(self, x, y, z):
        self.solid.add((x, y, z))

    def is_solid(self, x, y, z) -> bool:
        return (x, y, z) in self.solid

    def in_bounds(self, x, y, z) -> bool:
        r = self.res
        return 0 <= x < r and 0 <= y < r and 0 <= z < r

    def is_face_exposed(self, x, y, z, face: int) -> bool:
        if not self.is_solid(x, y, z): return False
        dx, dy, dz = FACE_DELTA[face]
        return not self.is_solid(x+dx, y+dy, z+dz)

    def all_exposed_faces(self) -> Set[Tuple]:
        out = set()
        for (x, y, z) in self.solid:
            for f in range(6):
                if self.is_face_exposed(x, y, z, f):
                    out.add(((x,y,z), f))
        return out

# ── Grid builders ─────────────────────────────────────────────────────────────

def box(grid, x0,x1,y0,y1,z0,z1):
    r = grid.res
    for x in range(max(0,x0), min(r,x1)):
        for y in range(max(0,y0), min(r,y1)):
            for z in range(max(0,z0), min(r,z1)):
                grid.set_solid(x,y,z)

def make_hollow_sphere(res):
    grid = VoxelGrid(res)
    c = res/2.0; r_o = res/2.0-0.5; r_i = r_o-1
    for x,y,z in itertools.product(range(res),repeat=3):
        d = math.sqrt((x-c)**2+(y-c)**2+(z-c)**2)
        if r_i < d <= r_o: grid.set_solid(x,y,z)
    return grid

def make_solid_sphere(res):
    grid = VoxelGrid(res)
    c = res/2.0; r = res/2.0-0.5
    for x,y,z in itertools.product(range(res),repeat=3):
        if (x-c)**2+(y-c)**2+(z-c)**2 <= r**2: grid.set_solid(x,y,z)
    return grid

def make_statue(res):
    grid = VoxelGrid(res)
    c = res//2; h = res
    box(grid, c-2,c+2, h*14//16,h,     c-2,c+2)  # head
    box(grid, c-3,c+3, h*8//16,h*14//16, c-2,c+2)  # torso
    box(grid, c-4,c-3, h*8//16,h*14//16, c-1,c+1)  # left arm
    box(grid, c+3,c+4, h*8//16,h*14//16, c-1,c+1)  # right arm
    box(grid, c-3,c-1, 0,h*8//16,       c-1,c+1)  # left leg
    box(grid, c+1,c+3, 0,h*8//16,       c-1,c+1)  # right leg
    return grid

def make_rough_slab(res):
    random.seed(42)
    grid = VoxelGrid(res)
    for x in range(res):
        for z in range(res):
            box(grid,x,x+1,4,6,z,z+1)
            if random.random()<0.4: box(grid,x,x+1,6,7,z,z+1)
            if random.random()<0.15: box(grid,x,x+1,7,8,z,z+1)
    return grid

def make_single_voxel(res):
    grid = VoxelGrid(res)
    c = res//2
    grid.set_solid(c,c,c)
    return grid

def make_solid_cube_4(res):
    grid = VoxelGrid(res)
    c = res//2
    box(grid,c-2,c+2,c-2,c+2,c-2,c+2)
    return grid

# ── OLD pipeline (v1.x face-sweep greedy + AABB packing) ─────────────────────

def old_greedy_face(grid, face):
    res = grid.res
    sweep_axis, u_axis, v_axis = FACE_AXES[face]
    dims = [res,res,res]
    sw=dims[sweep_axis]; ud=dims[u_axis]; vd=dims[v_axis]
    vs=16/sw; vu=16/ud; vv=16/vd

    def xyz(s,u,v):
        p=[0,0,0]; p[sweep_axis]=s; p[u_axis]=u; p[v_axis]=v
        return tuple(p)

    quads=[]
    for s in range(sw):
        exp={(u,v): grid.is_face_exposed(*xyz(s,u,v),face)
             for v in range(vd) for u in range(ud)}
        consumed=set()
        for v0 in range(vd):
            for u0 in range(ud):
                if (u0,v0) in consumed or not exp.get((u0,v0)): continue
                u1=u0+1
                while u1<ud and (u1,v0) not in consumed and exp.get((u1,v0)): u1+=1
                v1=v0+1
                while v1<vd:
                    if all((u,v1) not in consumed and exp.get((u,v1)) for u in range(u0,u1)): v1+=1
                    else: break
                for v in range(v0,v1):
                    for u in range(u0,u1): consumed.add((u,v))
                fr=[0.0,0.0,0.0]; to=[0.0,0.0,0.0]
                fr[sweep_axis]=s*vs;   to[sweep_axis]=(s+1)*vs
                fr[u_axis]=u0*vu;      to[u_axis]=u1*vu
                fr[v_axis]=v0*vv;      to[v_axis]=v1*vv
                quads.append(Quad(tuple(fr),tuple(to),face,s,u0,v0,u1-u0,v1-v0))
    return quads

def old_build_elements(quads):
    index={}; elements=[]
    for q in quads:
        key=(q.from_,q.to)
        if key not in index:
            index[key]=len(elements)
            el=McElement(q.from_,q.to)
            el.faces[FACE_NAMES[q.face]]=McFace(FACE_NAMES[q.face])
            elements.append(el)
        else:
            elements[index[key]].faces[FACE_NAMES[q.face]]=McFace(FACE_NAMES[q.face])
    return elements

def run_old(grid):
    quads=[]
    for f in range(6): quads.extend(old_greedy_face(grid,f))
    return quads, old_build_elements(quads)

# ── NEW pipeline (v2.0 3-D greedy boxes + AABB packing) ──────────────────────

def new_greedy_3d(grid):
    res = grid.res
    vs_x=16/res; vs_y=16/res; vs_z=16/res
    consumed=set()
    quads=[]
    boxes=0; interior=0

    for z0 in range(res):
        for y0 in range(res):
            for x0 in range(res):
                if not grid.is_solid(x0,y0,z0) or (x0,y0,z0) in consumed: continue

                # Expand X
                x1=x0+1
                while x1<res and grid.is_solid(x1,y0,z0) and (x1,y0,z0) not in consumed: x1+=1
                # Expand Y
                y1=y0+1
                while y1<res:
                    if all(grid.is_solid(x,y1,z0) and (x,y1,z0) not in consumed for x in range(x0,x1)): y1+=1
                    else: break
                # Expand Z
                z1=z0+1
                while z1<res:
                    if all(grid.is_solid(x,y,z1) and (x,y,z1) not in consumed
                           for y in range(y0,y1) for x in range(x0,x1)): z1+=1
                    else: break

                # Mark consumed
                for z in range(z0,z1):
                    for y in range(y0,y1):
                        for x in range(x0,x1): consumed.add((x,y,z))

                boxes+=1
                box_from=(x0*vs_x, y0*vs_y, z0*vs_z)
                box_to  =(x1*vs_x, y1*vs_y, z1*vs_z)

                emitted=0
                def try_emit(face, sweep_axis, u_axis, v_axis,
                             sweep_layer, us, vs_, uc, vc):
                    nonlocal emitted
                    for vi in range(vs_, vs_+vc):
                        for ui in range(us, us+uc):
                            p=[0,0,0]
                            p[sweep_axis]=sweep_layer
                            p[u_axis]=ui; p[v_axis]=vi
                            if grid.is_face_exposed(p[0],p[1],p[2],face):
                                quads.append(Quad(box_from,box_to,face,
                                                  sweep_layer,us,vs_,uc,vc))
                                emitted+=1
                                return

                # Down(-Y): sweep=Y, layer=y0,   u=X,v=Z
                try_emit(0, 1,0,2,  y0,    x0,z0, x1-x0,z1-z0)
                # Up(+Y):   sweep=Y, layer=y1-1, u=X,v=Z
                try_emit(1, 1,0,2,  y1-1,  x0,z0, x1-x0,z1-z0)
                # North(-Z):sweep=Z, layer=z0,   u=X,v=Y
                try_emit(2, 2,0,1,  z0,    x0,y0, x1-x0,y1-y0)
                # South(+Z):sweep=Z, layer=z1-1, u=X,v=Y
                try_emit(3, 2,0,1,  z1-1,  x0,y0, x1-x0,y1-y0)
                # West(-X): sweep=X, layer=x0,   u=Z,v=Y
                try_emit(4, 0,2,1,  x0,    z0,y0, z1-z0,y1-y0)
                # East(+X): sweep=X, layer=x1-1, u=Z,v=Y
                try_emit(5, 0,2,1,  x1-1,  z0,y0, z1-z0,y1-y0)

                if emitted==0: interior+=1

    return quads, boxes, interior

def new_build_elements(quads):
    # Identical AABB packing to v1.x — but now all faces of the same 3-D box
    # already share identical from_/to, so they collapse into one element.
    index={}; elements=[]
    for q in quads:
        key=(q.from_,q.to)
        if key not in index:
            index[key]=len(elements)
            el=McElement(q.from_,q.to)
            el.faces[FACE_NAMES[q.face]]=McFace(FACE_NAMES[q.face])
            elements.append(el)
        else:
            elements[index[key]].faces[FACE_NAMES[q.face]]=McFace(FACE_NAMES[q.face])
    return elements

def run_new(grid):
    quads, boxes, interior = new_greedy_3d(grid)
    return quads, new_build_elements(quads), boxes, interior

# ── Correctness checker ───────────────────────────────────────────────────────

def check_coverage(elements, grid, label):
    res = grid.res
    vox_size = 16.0/res
    errors=[]
    for ((x,y,z), face_id) in grid.all_exposed_faces():
        fname = FACE_NAMES[face_id]
        sweep_axis, u_axis, v_axis = FACE_AXES[face_id]
        coords=[x,y,z]

        found=False
        for el in elements:
            if fname not in el.faces: continue
            # Check AABB contains this voxel's face
            ef=el.from_; et=el.to
            # Sweep axis span must contain the voxel
            if ef[sweep_axis] > coords[sweep_axis]*vox_size+1e-9: continue
            if et[sweep_axis] < (coords[sweep_axis]+1)*vox_size-1e-9: continue
            # U and V axes must contain the voxel
            if ef[u_axis] > coords[u_axis]*vox_size+1e-9: continue
            if et[u_axis] < (coords[u_axis]+1)*vox_size-1e-9: continue
            if ef[v_axis] > coords[v_axis]*vox_size+1e-9: continue
            if et[v_axis] < (coords[v_axis]+1)*vox_size-1e-9: continue
            found=True; break

        if not found:
            errors.append(f"    voxel={x,y,z} face={fname}")

    n_exposed = len(grid.all_exposed_faces())
    if errors:
        print(f"  ✗ [{label}] {len(errors)}/{n_exposed} exposed faces NOT covered:")
        for e in errors[:3]: print(e)
        return False
    else:
        print(f"  ✓ [{label}] All {n_exposed} exposed faces covered correctly")
        return True

def covered_voxel_faces(elements, grid):
    """
    Returns the set of (voxel_coord, face_id) pairs that are covered by
    the element list.  This is the canonical 'what is rendered' set —
    independent of AABB size.  OLD uses 1-voxel-thick slabs; NEW uses full
    3-D box extents.  Both must cover the same exposed voxel faces.
    """
    res = grid.res
    vs  = 16.0 / res
    covered = set()
    for ((x,y,z), face_id) in grid.all_exposed_faces():
        fname = FACE_NAMES[face_id]
        sweep_axis, u_axis, v_axis = FACE_AXES[face_id]
        coords = [x, y, z]
        for el in elements:
            if fname not in el.faces: continue
            ef = el.from_; et = el.to
            if ef[sweep_axis] > coords[sweep_axis]*vs + 1e-9: continue
            if et[sweep_axis] < (coords[sweep_axis]+1)*vs - 1e-9: continue
            if ef[u_axis]     > coords[u_axis]*vs + 1e-9: continue
            if et[u_axis]     < (coords[u_axis]+1)*vs - 1e-9: continue
            if ef[v_axis]     > coords[v_axis]*vs + 1e-9: continue
            if et[v_axis]     < (coords[v_axis]+1)*vs - 1e-9: continue
            covered.add(((x,y,z), face_id))
            break
    return covered

def coverage_sets_equal(el_old, el_new, grid):
    """
    Compare rendered exposed voxel faces — NOT internal AABBs, which
    legitimately differ between OLD (1-voxel slabs) and NEW (full boxes).
    """
    cov_old = covered_voxel_faces(el_old, grid)
    cov_new = covered_voxel_faces(el_new, grid)
    all_exp = grid.all_exposed_faces()
    if cov_old == cov_new == all_exp:
        print(f"  ✓ Both pipelines render IDENTICAL voxel faces ({len(all_exp)} total)")
        return True
    miss = cov_old - cov_new; extra = cov_new - cov_old
    print(f"  ✗ Mismatch: {len(miss)} in OLD not in NEW, {len(extra)} extra in NEW")
    return False

# ── Test runner ───────────────────────────────────────────────────────────────

def run_test(name, grid):
    res=grid.res
    solid=len(grid.solid)
    exposed=len(grid.all_exposed_faces())

    print(f"\n{'═'*74}")
    print(f"  {name}  (res={res}, solid={solid}, exposed faces={exposed})")
    print(f"{'═'*74}")

    old_quads, old_els = run_old(grid)
    new_quads, new_els, boxes, interior = run_new(grid)

    print(f"\n  Quads emitted (before AABB packing):")
    print(f"    OLD (face-sweep) : {len(old_quads):>6}")
    print(f"    NEW (3-D greedy) : {len(new_quads):>6}   "
          f"({boxes} boxes found, {interior} interior/zero-face)")

    print(f"\n  MC Elements (after AABB packing):")
    print(f"    OLD              : {len(old_els):>6}")
    print(f"    NEW              : {len(new_els):>6}   "
          f"({len(old_els)-len(new_els):+d}, "
          f"{100*(len(old_els)-len(new_els))//max(1,len(old_els))}% reduction)")

    print(f"\n  Correctness:")
    ok1=check_coverage(old_els, grid, "OLD")
    ok2=check_coverage(new_els, grid, "NEW")
    ok3=coverage_sets_equal(old_els, new_els, grid)

    if len(new_els) <= len(old_els):
        print(f"  ✓ NEW ≤ OLD elements (never worse)")
    else:
        print(f"  ✗ NEW > OLD — regression!")

    return ok1 and ok2 and ok3 and len(new_els)<=len(old_els)

# ── Main ──────────────────────────────────────────────────────────────────────

if __name__=="__main__":
    print("mc-voxelizer 3-D Greedy Verifier  (v2.0 vs v1.x)")
    print("NEW: volume-boxing replaces face-sweep; from/to = full box extents")
    print("samplePixel (sweepLayer/uStart/vStart) — UNCHANGED\n")

    results=[]
    results.append(run_test("A) Hollow sphere           (organic curved surface)",  make_hollow_sphere(16)))
    results.append(run_test("B) Solid sphere  [solidFill] (interior absorbed)",     make_solid_sphere(16)))
    results.append(run_test("C) Stone statue  [solidFill] (your use-case)",         make_statue(16)))
    results.append(run_test("D) Rough slab               (hair/clothing proxy)",    make_rough_slab(16)))
    results.append(run_test("E) Single voxel             (6 faces → 1 element)",   make_single_voxel(16)))
    results.append(run_test("F) Solid 4×4×4 cube [solidFill]",                     make_solid_cube_4(16)))
    results.append(run_test("G) Stone statue  [solidFill] higher res",              make_statue(32)))

    print(f"\n{'═'*74}")
    if all(results):
        print("  ALL TESTS PASSED — v2.0 is visually identical with fewer elements.")
    else:
        print("  SOME TESTS FAILED.")
    print(f"{'═'*74}\n")
